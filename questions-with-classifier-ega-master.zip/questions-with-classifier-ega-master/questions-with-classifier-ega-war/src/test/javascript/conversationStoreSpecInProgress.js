/* Copyright IBM Corp. 2015 Licensed under the Apache License, Version 2.0 */

describe("ConversationStore tests", function() {
	it("Should have access to Dispatcher", function(){
        expect(Dispatcher).toBeDefined();
	});
});
