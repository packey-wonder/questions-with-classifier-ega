# questions-with-classifier-ega-test

This project contains integration tests for the WAR project.

It also creates a WAR file containing a mocked classifier service.
This is used for running local integration tests without requiring any services in Bluemix.